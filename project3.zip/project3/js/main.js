/*Game Variables*/
let money = 0;
let tree = document.querySelector("#treetoclick");
let moneyText = document.getElementById("moneyamount");
let fertilizerCount = 0;
let cryptoCount = 0;
let hedgeCount = 0;
tree.onclick = treeClick;

document.querySelector("#treetoclick").onclick = treeClick;

function treeClick(number){
    money = money + number;
    document.getElementById("moneyamount").innerHTML = "Money: $" +money;
};

function buyFertilizer(){
    let fertilizerCost = Math.floor(10* Math.pow(1.1,fertilizerCount));
    if(money >= fertilizerCost){
        fertilizerCount += 1;
        money -= fertilizerCost;
        document.querySelector("#moneyamount").innerHTML ="Money: $"+ money;
        document.querySelector("#fertilizers").innerHTML = "Count: " + fertilizerCount;
    }
    let nextCost = Math.floor(10* Math.pow(1.1,fertilizerCount));
    document.querySelector("#fertilizerCost").innerHTML = "Cost: $" + nextCost;

}

function buyCryptoCurrency(){
    let cryptoCost = Math.floor(10* Math.pow(1.2,cryptoCount));
    if(money >= fertilizerCost){
        cryptoCount += 1;
        money -= cryptoCost;
        document.querySelector("#moneyamount").innerHTML ="Money: $"+ money;
        document.querySelector("#cryptos").innerHTML = "Count: " + cryptoCount;
    }
    let nextCost = Math.floor(10* Math.pow(1.2,cryptoCount));
    document.querySelector("#cryptoCost").innerHTML = "Cost: $" + nextCost;

}

function buyHedgeTrimmer(){
    let hedgeCost = Math.floor(10* Math.pow(1.3,hedgeCount));
    if(money >= hedgeCost){
        hedgeCount += 1;
        money -= hedgeCount;
        document.querySelector("#moneyamount").innerHTML ="Money: $"+ money;
        document.querySelector("#hedges").innerHTML = "Count: " + hedgeCount;
    }
    let nextCost = Math.floor(10* Math.pow(1.3,hedgeCount));
    document.querySelector("#hedgeCost").innerHTML = "Cost: $" + nextCost;

}



let moneypersec = setInterval(treeClick(fertilizerCount),1000);
let moneypersec2 = setInterval(treeClick(cryptoCount),1000);
let moneypersec3 = setInterval(treeClick(hedgeCount),1000);
function update(){

}
window.setInterval(function() {
    treeClick(fertilizerCount);
}, 1000);
